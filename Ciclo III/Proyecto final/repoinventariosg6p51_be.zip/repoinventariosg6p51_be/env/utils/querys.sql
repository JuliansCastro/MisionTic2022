--DROP all tables from DB
DROP TABLE "public"."auth_group" CASCADE;
DROP TABLE "public"."auth_group_permissions" CASCADE;
DROP TABLE "public"."auth_permission" CASCADE;
DROP TABLE "public"."django_admin_log" CASCADE;
DROP TABLE "public"."django_content_type" CASCADE;
DROP TABLE "public"."django_migrations" CASCADE;
DROP TABLE "public"."django_session" CASCADE;
DROP TABLE "public"."g6App_cliente" CASCADE;
DROP TABLE "public"."g6App_detalle_venta" CASCADE;
DROP TABLE "public"."g6App_empleado" CASCADE;
DROP TABLE "public"."g6App_empleado_groups" CASCADE;
DROP TABLE "public"."g6App_empleado_user_permissions" CASCADE;
DROP TABLE "public"."g6App_inventario" CASCADE;
DROP TABLE "public"."g6App_miscelanea" CASCADE;
DROP TABLE "public"."g6App_producto" CASCADE;
DROP TABLE "public"."g6App_venta" CASCADE;


--INSERT DATA ON TABLES
INSERT INTO "public"."g6App_miscelanea" (id, nit, nombre_misc, direccion_misc) VALUES (001, 25560663, 'Tienda Pepe.com', 'Carrera 30 #2600');

--UPDATE DATA ON TABLES
UPDATE "public"."g6App_miscelanea" SET "direccion_misc" = 'Carrera 30 #26-00' WHERE "id" = 1;
UPDATE "public"."g6App_miscelanea" SET "nombre_misc" = 'Pepe.com' WHERE "id" = 3;

--DELETE ROWS FROM TABLES
DELETE FROM "public"."g6App_empleado" WHERE ("id" = 4);