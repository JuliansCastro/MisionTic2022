from django.db import models

class Miscelanea(models.Model):
    id = models.BigAutoField(primary_key=True) 
    nit = models.CharField('nit', default=0, max_length=15)
    nombre_misc = models.CharField('nombre_miscelanea', max_length=45)
    direccion_misc = models.CharField('direccion_miscelanea', max_length=150, unique=True)
    
