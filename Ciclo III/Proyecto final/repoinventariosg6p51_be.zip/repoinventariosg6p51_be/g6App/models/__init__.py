from .cliente import Cliente
from .detalle_venta import Detalle_venta
from .empleado import Empleado
from .inventario import Inventario
from .miscelanea import Miscelanea
from .producto import Producto
from .venta import Venta
