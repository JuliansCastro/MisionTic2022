from django.apps import AppConfig


class G6AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'g6App'
