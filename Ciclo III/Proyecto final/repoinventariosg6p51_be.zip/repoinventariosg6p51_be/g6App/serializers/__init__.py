from .empleadoSerializer import EmpleadoSerializer
from .miscelaneaSerializer import MiscelaneaSerializer
from .productoSerializer import ProductoSerializer
from .inventarioSerializer import InventarioSerializer

