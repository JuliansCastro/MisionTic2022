from g6App.models.miscelanea import Miscelanea
from rest_framework import serializers
from g6App.serializers.empleadoSerializer import EmpleadoSerializer


class MiscelaneaSerializer(serializers.ModelSerializer):
    #empleado = empleadoSerializer()
    class Meta:
        model = Miscelanea
        fields = ['id','nit', 'nombre_misc','direccion_misc']
    '''
    def create(self, validated_data):
        empleado  = validated_data.pop('empleado')
        miscelaneaInstance = Miscelanea.objects.create(**validated_data)
        empleado.objects.create(user=miscelaneaInstance, **miscelaneaInstance)
        return userInstance
    '''
    def to_representation(self, obj):
        miscelanea = Miscelanea.objects.get(id=obj.id)
        return{
            'id' : miscelanea.id,
            'nit' : miscelanea.nit,
            'nombre_misc' : miscelanea.nombre_misc,
            'direccion_misc' :  miscelanea.direccion_misc
        }