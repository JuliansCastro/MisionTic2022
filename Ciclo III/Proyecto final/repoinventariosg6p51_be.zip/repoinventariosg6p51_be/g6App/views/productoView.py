from rest_framework import generics
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from g6App.models.producto import Producto
from g6App.serializers.productoSerializer import ProductoSerializer
from g6App.models.producto import Producto


#listar los productos existentes
class productoDetailView(generics.ListAPIView):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer

    def get(self, request, *args, **kwargs):
           queryset = self.get_queryset()
           serializer = ProductoSerializer(queryset, many=True)
           return Response(serializer.data)
   
#crear un producto nuevo
class productoCreateView(generics.CreateAPIView):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer

    def post(self, request, *args, **kwargs):
            queryset = self.post_queryset()
            serializer = ProductoSerializer(queryset, many=True)
            return Response(serializer.data)


#actualizar un producto
class productoUpdateView(generics.RetrieveUpdateAPIView):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer


    def put(self, request, *args, **kwargs):
            queryset = self.put_queryset()
            serializer = ProductoSerializer(queryset, many=True)
            return Response(serializer.data)

#eliminar un producto
class productoDeleteView(generics.DestroyAPIView):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer
   
    def delete(self, request, *args, **kwargs):
            queryset = self.delete_queryset()
            serializer = ProductoSerializer(queryset, many=True)
            return Response(serializer.data)
