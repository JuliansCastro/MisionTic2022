from rest_framework import generics
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from g6App.models.miscelanea import Miscelanea
from g6App.serializers.miscelaneaSerializer import MiscelaneaSerializer


class miscelaneaView(generics.ListAPIView): # Lista todas las miscelaneas
    queryset = Miscelanea.objects.all()
    serializer_class = MiscelaneaSerializer
    permission_classes = (IsAuthenticated,) #Solo los usuarios autenticados pueden acceder a este endpoint

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = MiscelaneaSerializer(queryset, many=True)
        return Response(serializer.data)


class miscelaneaCreateView(generics.CreateAPIView): # Crea una miscelanea
    serializer_class= MiscelaneaSerializer
    permission_classes = (IsAuthenticated,) #Solo los usuarios autenticados pueden acceder a este endpoint
    
    def post(self, request, *args, **kwargs):
        queryset = self.post_queryset()
        serializer = MiscelaneaSerializer(queryset, many=True)
        return Response(serializer.data)
