


class InventarioView():
    pass

