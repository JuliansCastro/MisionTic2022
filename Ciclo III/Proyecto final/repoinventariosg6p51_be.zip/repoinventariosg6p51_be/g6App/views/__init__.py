from .miscelaneaView import miscelaneaView, miscelaneaCreateView
from .productoView import productoDetailView, productoCreateView, productoUpdateView, productoDeleteView
from .empleadoView import EmpleadoCreateView , EmpleadoDetailView
from .inventarioView import InventarioView